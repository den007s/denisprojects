// FUNCTIE DE AFISAT OPTIUNILE DE SORTARE
function afisareOptiuniSortare() {
    document.getElementById("buton-sortare-optiuni").classList.toggle("show");
}

// EVENIMENTE INREGISTRATE PE PAGINA
function inregistrareEvenimenteClickPagina() {
    inchidereOptiuniCautare();
}


// FUNCTII DE GESTIONAT SEARCHBAR-UL
function arataProduseCautate(cuvant) {
    var opt = document.getElementById("optiuni-cautare");
    if (cuvant.length == 0) {
        opt.innerHTML = "";
        return;
    }

    var i, detaliiProdus, numeProdus, numeEfectiv, raspuns = "";
    var list = document.getElementById("produse");
    var produse = list.getElementsByClassName("caseta-produs");
    var optiuniAfisate = 5;
    for (i = 0; i < produse.length; i++) {
        detaliiProdus = produse[i].getElementsByClassName("detalii-produs");
        numeProdus = detaliiProdus[0].getElementsByClassName("nume-produs");
        numeEfectiv = numeProdus[0].innerHTML;

        if (numeEfectiv.toLocaleLowerCase().includes(cuvant.toLocaleLowerCase())) {
            raspuns = raspuns + "<p onclick='trimitereSpreCautare(this)'>" + numeEfectiv + "</p>";
            optiuniAfisate--;
            if (!optiuniAfisate) break;
        }
    }

    if (raspuns == "") raspuns = "<p>Nicio Sugestie!</p>";
    opt.innerHTML = raspuns;
    opt.style.display = "flex";
}

function trimitereSpreCautare(textDeCautat) {
    var searchInput = document.getElementById("search-input");
    searchInput.value = textDeCautat.innerHTML;
    inchidereOptiuniCautare();
}

function inchidereOptiuniCautare() {
    var opt = document.getElementById("optiuni-cautare");
    opt.innerHTML = "";
}

function cautareProduse() {
    var searchInput = document.getElementById("search-input");
    if (searchInput.value.length) {
        var list = document.getElementById("produse");
        var produse = list.getElementsByClassName("caseta-produs");
        var detaliiProdus, numeProdus, numeEfectiv;
        var i;
        for (i = 0; i < produse.length; i++) {
            detaliiProdus = produse[i].getElementsByClassName("detalii-produs");
            numeProdus = detaliiProdus[0].getElementsByClassName("nume-produs");
            numeEfectiv = numeProdus[0].innerHTML;
            if (!numeEfectiv.toLocaleLowerCase().includes(searchInput.value.toLocaleLowerCase())) {
                produse[i].style.display = "none";
            } else {
                produse[i].style.display = "block";
            }
        }
        searchInput.value = "";
        inchidereOptiuniCautare();
    }
}
